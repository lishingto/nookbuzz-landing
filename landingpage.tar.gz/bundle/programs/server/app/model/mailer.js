(function(){Mailer = new Mongo.Collection('mailer');

Mailer.allow({
    insert: function insert() {
        return this.userId ? true : false;
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9tb2RlbC9tYWlsZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxHQUFHLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7QUFFeEMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNULFVBQU0sRUFBRSxrQkFBWTtBQUNoQixlQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLEtBQUssQ0FBRTtLQUMzQztDQUNBLENBQUMsQ0FBQyIsImZpbGUiOiIvbW9kZWwvbWFpbGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiTWFpbGVyID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ21haWxlcicpO1xyXG5cclxuTWFpbGVyLmFsbG93KHtcclxuICAgIGluc2VydDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiAodGhpcy51c2VySWQgPyB0cnVlIDogZmFsc2UpO1xyXG59XHJcbn0pOyJdfQ==
}).call(this);

//# sourceMappingURL=mailer.js.map
