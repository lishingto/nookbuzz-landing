(function(){var settings = {
    emailFrom: "NookBuzz Greetings <hello@nookbuzz.com>",
    host: "http://localhost:3000"
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zZXJ2ZXIvc3RhcnR1cC9zZXR0aW5ncy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxJQUFJLFFBQVEsR0FBRztBQUNYLGFBQVMsRUFBRSx5Q0FBeUM7QUFDcEQsUUFBSSxFQUFFLHVCQUF1QjtDQUNoQyxDQUFDIiwiZmlsZSI6Ii9zZXJ2ZXIvc3RhcnR1cC9zZXR0aW5ncy5qcyIsInNvdXJjZXNDb250ZW50IjpbInZhciBzZXR0aW5ncyA9IHtcclxuICAgIGVtYWlsRnJvbTogXCJOb29rQnV6eiBHcmVldGluZ3MgPGhlbGxvQG5vb2tidXp6LmNvbT5cIixcclxuICAgIGhvc3Q6IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwXCJcclxufTsiXX0=
}).call(this);

//# sourceMappingURL=settings.js.map
