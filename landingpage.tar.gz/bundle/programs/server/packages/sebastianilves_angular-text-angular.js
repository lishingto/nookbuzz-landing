(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/sebastianilves_angular-text-angular/packages/sebastianil //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['sebastianilves:angular-text-angular'] = {};

})();

//# sourceMappingURL=sebastianilves_angular-text-angular.js.map
